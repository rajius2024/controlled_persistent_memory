# Final episodic fact controlled-memory results

Method: Controlled typed memory with preference/state memories + episodic_fact memories.

Slices:
- 450–499: 29/50 = 58.0%
- 500–524: 19/25 = 76.0%
- 525–549: 14/25 = 56.0%
- 550–587: 30/38 = 78.9%

Combined:
- 92/138 = 66.7%

Comparison:
- Old controlled: 84/138 = 60.9%
- Vanilla RAG: 86/138 = 62.3%
